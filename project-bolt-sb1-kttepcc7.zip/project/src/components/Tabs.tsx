import { ReactNode } from 'react';

interface TabsProps {
  tabs: {
    id: string;
    label: string;
    icon: ReactNode;
  }[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
}

export function Tabs({ tabs, activeTab, onTabChange }: TabsProps) {
  return (
    <div className="flex gap-2 border-b border-cyan-500/30 mb-6">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`
            flex items-center gap-2 px-6 py-3 font-medium transition-all duration-300
            relative group
            ${
              activeTab === tab.id
                ? 'text-cyan-400'
                : 'text-gray-400 hover:text-cyan-300'
            }
          `}
        >
          <span className="text-xl">{tab.icon}</span>
          <span>{tab.label}</span>
          {activeTab === tab.id && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 shadow-lg shadow-cyan-500/50" />
          )}
          <div className="absolute inset-0 bg-cyan-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
        </button>
      ))}
    </div>
  );
}
