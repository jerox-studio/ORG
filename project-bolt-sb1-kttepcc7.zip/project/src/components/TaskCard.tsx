import { CheckCircle2, Circle, Clock, Trash2, Edit, PlayCircle } from 'lucide-react';
import { Task } from '../types/task';

interface TaskCardProps {
  task: Task;
  onStatusChange: (taskId: string, status: Task['status']) => void;
  onDelete: (taskId: string) => void;
  onEdit: (task: Task) => void;
}

const priorityColors = {
  low: 'from-gray-500/20 to-gray-600/20 border-gray-500/30',
  medium: 'from-blue-500/20 to-blue-600/20 border-blue-500/30',
  high: 'from-orange-500/20 to-orange-600/20 border-orange-500/30',
  urgent: 'from-red-500/20 to-red-600/20 border-red-500/30',
};

const categoryIcons = {
  work: '💼',
  personal: '🏠',
  health: '❤️',
  learning: '📚',
};

export function TaskCard({ task, onStatusChange, onDelete, onEdit }: TaskCardProps) {
  const isCompleted = task.status === 'completed';
  const isPending = task.status === 'pending';
  const isInProgress = task.status === 'in_progress';

  return (
    <div
      className={`
        bg-gradient-to-br ${priorityColors[task.priority]}
        border backdrop-blur-sm rounded-xl p-4
        transition-all duration-300 hover:scale-[1.02] hover:shadow-lg hover:shadow-cyan-500/10
        group relative overflow-hidden
      `}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

      <div className="relative z-10">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-start gap-3 flex-1">
            <button
              onClick={() =>
                onStatusChange(
                  task.id,
                  isCompleted ? 'pending' : 'completed'
                )
              }
              className="mt-1 transition-transform hover:scale-110"
            >
              {isCompleted ? (
                <CheckCircle2 className="w-6 h-6 text-cyan-400" />
              ) : (
                <Circle className="w-6 h-6 text-gray-400 hover:text-cyan-400" />
              )}
            </button>

            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-2xl">{categoryIcons[task.category]}</span>
                <h3
                  className={`text-lg font-semibold ${
                    isCompleted ? 'line-through text-gray-500' : 'text-white'
                  }`}
                >
                  {task.title}
                </h3>
              </div>

              {task.description && (
                <p className="text-gray-400 text-sm mb-2">{task.description}</p>
              )}

              <div className="flex items-center gap-3 text-xs">
                {task.scheduled_time && (
                  <span className="flex items-center gap-1 text-cyan-400">
                    <Clock className="w-3 h-3" />
                    {task.scheduled_time}
                  </span>
                )}
                {task.duration_minutes && (
                  <span className="text-gray-400">
                    {task.duration_minutes} min
                  </span>
                )}
                <span
                  className={`
                    px-2 py-0.5 rounded-full text-xs font-medium
                    ${task.priority === 'urgent' ? 'bg-red-500/20 text-red-400' : ''}
                    ${task.priority === 'high' ? 'bg-orange-500/20 text-orange-400' : ''}
                    ${task.priority === 'medium' ? 'bg-blue-500/20 text-blue-400' : ''}
                    ${task.priority === 'low' ? 'bg-gray-500/20 text-gray-400' : ''}
                  `}
                >
                  {task.priority}
                </span>
              </div>
            </div>
          </div>

          <div className="flex gap-2">
            {isPending && (
              <button
                onClick={() => onStatusChange(task.id, 'in_progress')}
                className="p-2 hover:bg-cyan-500/20 rounded-lg transition-colors"
                title="Start task"
              >
                <PlayCircle className="w-4 h-4 text-cyan-400" />
              </button>
            )}
            <button
              onClick={() => onEdit(task)}
              className="p-2 hover:bg-cyan-500/20 rounded-lg transition-colors"
            >
              <Edit className="w-4 h-4 text-gray-400" />
            </button>
            <button
              onClick={() => onDelete(task.id)}
              className="p-2 hover:bg-red-500/20 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4 text-red-400" />
            </button>
          </div>
        </div>

        {isInProgress && (
          <div className="mt-3 pt-3 border-t border-cyan-500/20">
            <div className="flex items-center gap-2 text-cyan-400 text-sm animate-pulse">
              <div className="w-2 h-2 bg-cyan-400 rounded-full animate-ping" />
              In Progress
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
