import { Task } from '../types/task';
import { TrendingUp, Target, Clock, CheckCircle } from 'lucide-react';

interface ProgressChartProps {
  tasks: Task[];
}

export function ProgressChart({ tasks }: ProgressChartProps) {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter((t) => t.status === 'completed').length;
  const inProgressTasks = tasks.filter((t) => t.status === 'in_progress').length;
  const pendingTasks = tasks.filter((t) => t.status === 'pending').length;

  const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  const categoryStats = tasks.reduce((acc, task) => {
    acc[task.category] = (acc[task.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const categoryData = [
    { name: 'Work', value: categoryStats.work || 0, icon: '💼', color: 'from-blue-500 to-cyan-500' },
    { name: 'Personal', value: categoryStats.personal || 0, icon: '🏠', color: 'from-purple-500 to-pink-500' },
    { name: 'Health', value: categoryStats.health || 0, icon: '❤️', color: 'from-red-500 to-orange-500' },
    { name: 'Learning', value: categoryStats.learning || 0, icon: '📚', color: 'from-green-500 to-emerald-500' },
  ];

  const maxValue = Math.max(...categoryData.map(d => d.value), 1);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/30 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-2">
            <Target className="w-8 h-8 text-cyan-400" />
            <span className="text-3xl font-bold text-white">{totalTasks}</span>
          </div>
          <p className="text-gray-400 text-sm">Total Tasks</p>
        </div>

        <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-8 h-8 text-green-400" />
            <span className="text-3xl font-bold text-white">{completedTasks}</span>
          </div>
          <p className="text-gray-400 text-sm">Completed</p>
        </div>

        <div className="bg-gradient-to-br from-orange-500/20 to-yellow-500/20 border border-orange-500/30 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-8 h-8 text-orange-400" />
            <span className="text-3xl font-bold text-white">{inProgressTasks}</span>
          </div>
          <p className="text-gray-400 text-sm">In Progress</p>
        </div>

        <div className="bg-gradient-to-br from-gray-500/20 to-slate-500/20 border border-gray-500/30 rounded-xl p-6 backdrop-blur-sm">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-gray-400" />
            <span className="text-3xl font-bold text-white">{completionRate.toFixed(0)}%</span>
          </div>
          <p className="text-gray-400 text-sm">Completion Rate</p>
        </div>
      </div>

      <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/50 border border-cyan-500/30 rounded-xl p-6 backdrop-blur-sm">
        <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-cyan-400" />
          Tasks by Category
        </h3>

        <div className="space-y-4">
          {categoryData.map((category) => (
            <div key={category.name}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-white font-medium flex items-center gap-2">
                  <span className="text-2xl">{category.icon}</span>
                  {category.name}
                </span>
                <span className="text-cyan-400 font-bold">{category.value}</span>
              </div>
              <div className="h-3 bg-gray-700/50 rounded-full overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r ${category.color} transition-all duration-500 shadow-lg`}
                  style={{ width: `${(category.value / maxValue) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-gray-900/50 to-gray-800/50 border border-cyan-500/30 rounded-xl p-6 backdrop-blur-sm">
        <h3 className="text-xl font-bold text-white mb-4">Status Distribution</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-3xl font-bold text-gray-400 mb-1">{pendingTasks}</div>
            <div className="text-sm text-gray-500">Pending</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-orange-400 mb-1">{inProgressTasks}</div>
            <div className="text-sm text-gray-500">In Progress</div>
          </div>
          <div className="text-center">
            <div className="text-3xl font-bold text-green-400 mb-1">{completedTasks}</div>
            <div className="text-sm text-gray-500">Completed</div>
          </div>
        </div>
      </div>
    </div>
  );
}
