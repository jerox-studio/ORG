export type TaskCategory = 'work' | 'personal' | 'health' | 'learning';
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string;
  category: TaskCategory;
  priority: TaskPriority;
  status: TaskStatus;
  scheduled_date: string;
  scheduled_time?: string;
  duration_minutes?: number;
  completed_at?: string;
  created_at: string;
  updated_at: string;
}

export interface NewTask {
  title: string;
  description?: string;
  category: TaskCategory;
  priority: TaskPriority;
  scheduled_date: string;
  scheduled_time?: string;
  duration_minutes?: number;
}
