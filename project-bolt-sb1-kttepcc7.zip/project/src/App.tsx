import { useState, useEffect } from 'react';
import { Plus, ListTodo, BarChart3, Calendar, Zap } from 'lucide-react';
import { supabase } from './lib/supabase';
import { Task, NewTask } from './types/task';
import { Tabs } from './components/Tabs';
import { TaskCard } from './components/TaskCard';
import { NewTaskModal } from './components/NewTaskModal';
import { ProgressChart } from './components/ProgressChart';

function App() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTab, setActiveTab] = useState('today');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTasks();
  }, []);

  const fetchTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .order('scheduled_date', { ascending: true })
        .order('scheduled_time', { ascending: true });

      if (error) throw error;
      setTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTask = async (newTask: NewTask) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase.from('tasks').insert([
        {
          ...newTask,
          user_id: user.id,
          status: 'pending',
        },
      ]);

      if (error) throw error;
      await fetchTasks();
      setIsModalOpen(false);
    } catch (error) {
      console.error('Error creating task:', error);
    }
  };

  const handleUpdateTask = async (newTask: NewTask) => {
    if (!editingTask) return;

    try {
      const { error } = await supabase
        .from('tasks')
        .update(newTask)
        .eq('id', editingTask.id);

      if (error) throw error;
      await fetchTasks();
      setIsModalOpen(false);
      setEditingTask(null);
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const handleStatusChange = async (taskId: string, status: Task['status']) => {
    try {
      const updateData: { status: Task['status']; completed_at?: string } = { status };
      if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
      }

      const { error } = await supabase
        .from('tasks')
        .update(updateData)
        .eq('id', taskId);

      if (error) throw error;
      await fetchTasks();
    } catch (error) {
      console.error('Error updating task status:', error);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      const { error } = await supabase.from('tasks').delete().eq('id', taskId);

      if (error) throw error;
      await fetchTasks();
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const handleEditTask = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const today = new Date().toISOString().split('T')[0];
  const todayTasks = tasks.filter((task) => task.scheduled_date === today);
  const upcomingTasks = tasks.filter((task) => task.scheduled_date > today);
  const allTasks = tasks;

  const getFilteredTasks = () => {
    switch (activeTab) {
      case 'today':
        return todayTasks;
      case 'upcoming':
        return upcomingTasks;
      case 'all':
        return allTasks;
      default:
        return [];
    }
  };

  const filteredTasks = activeTab === 'analytics' ? [] : getFilteredTasks();

  const tabs = [
    { id: 'today', label: 'Today', icon: <Calendar /> },
    { id: 'upcoming', label: 'Upcoming', icon: <Zap /> },
    { id: 'all', label: 'All Tasks', icon: <ListTodo /> },
    { id: 'analytics', label: 'Analytics', icon: <BarChart3 /> },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-black">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-900/20 via-transparent to-transparent" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-500 bg-clip-text text-transparent">
              The Routine
            </h1>
            <button
              onClick={() => {
                setEditingTask(null);
                setIsModalOpen(true);
              }}
              className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 hover:scale-105"
            >
              <Plus className="w-5 h-5" />
              New Task
            </button>
          </div>
          <p className="text-gray-400 text-lg">Master your day, one task at a time</p>
        </div>

        <Tabs tabs={tabs} activeTab={activeTab} onTabChange={setActiveTab} />

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cyan-500" />
          </div>
        ) : (
          <>
            {activeTab === 'analytics' ? (
              <ProgressChart tasks={allTasks} />
            ) : (
              <div className="space-y-4">
                {filteredTasks.length === 0 ? (
                  <div className="text-center py-20">
                    <div className="text-6xl mb-4">🎯</div>
                    <p className="text-gray-400 text-xl mb-4">No tasks yet</p>
                    <p className="text-gray-500">
                      Create your first task to get started on your routine
                    </p>
                  </div>
                ) : (
                  filteredTasks.map((task) => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      onStatusChange={handleStatusChange}
                      onDelete={handleDeleteTask}
                      onEdit={handleEditTask}
                    />
                  ))
                )}
              </div>
            )}
          </>
        )}
      </div>

      <NewTaskModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingTask(null);
        }}
        onSave={editingTask ? handleUpdateTask : handleCreateTask}
        editingTask={editingTask}
      />
    </div>
  );
}

export default App;
