/*
  # The Routine - Daily Planner Database Schema

  ## Overview
  This migration creates the database structure for "The Routine" daily planner application,
  enabling users to manage their daily tasks with categories, priorities, and time tracking.

  ## New Tables
  
  ### `tasks`
  Stores all user tasks with their details and tracking information.
  
  **Columns:**
  - `id` (uuid, primary key) - Unique identifier for each task
  - `user_id` (uuid) - Reference to the authenticated user who owns the task
  - `title` (text) - Task title/name
  - `description` (text, optional) - Detailed description of the task
  - `category` (text) - Task category: 'work', 'personal', 'health', 'learning'
  - `priority` (text) - Priority level: 'low', 'medium', 'high', 'urgent'
  - `status` (text) - Current status: 'pending', 'in_progress', 'completed', 'cancelled'
  - `scheduled_date` (date) - Date when the task is scheduled
  - `scheduled_time` (time, optional) - Specific time for the task
  - `duration_minutes` (integer, optional) - Expected duration in minutes
  - `completed_at` (timestamptz, optional) - When the task was marked complete
  - `created_at` (timestamptz) - When the task was created
  - `updated_at` (timestamptz) - When the task was last updated

  ## Security
  
  ### Row Level Security (RLS)
  - RLS is enabled on the `tasks` table
  - Users can only view their own tasks
  - Users can only insert tasks for themselves
  - Users can only update their own tasks
  - Users can only delete their own tasks

  ### Policies
  1. **"Users can view own tasks"** - SELECT policy for authenticated users
  2. **"Users can insert own tasks"** - INSERT policy for authenticated users
  3. **"Users can update own tasks"** - UPDATE policy for authenticated users
  4. **"Users can delete own tasks"** - DELETE policy for authenticated users

  ## Indexes
  - Index on `user_id` for efficient user-specific queries
  - Index on `scheduled_date` for date-based filtering
  - Composite index on `user_id` and `status` for status filtering
*/

CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  category text NOT NULL DEFAULT 'personal',
  priority text NOT NULL DEFAULT 'medium',
  status text NOT NULL DEFAULT 'pending',
  scheduled_date date NOT NULL DEFAULT CURRENT_DATE,
  scheduled_time time,
  duration_minutes integer,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  CONSTRAINT valid_category CHECK (category IN ('work', 'personal', 'health', 'learning')),
  CONSTRAINT valid_priority CHECK (priority IN ('low', 'medium', 'high', 'urgent')),
  CONSTRAINT valid_status CHECK (status IN ('pending', 'in_progress', 'completed', 'cancelled'))
);

ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own tasks"
  ON tasks FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own tasks"
  ON tasks FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own tasks"
  ON tasks FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own tasks"
  ON tasks FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_scheduled_date ON tasks(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_tasks_user_status ON tasks(user_id, status);